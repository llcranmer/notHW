#include <iostream>
#include <cfloat>
#include <fstream>
#include <string>
#include "msTreeType.h"
#include "ArgumentManager.h"
#include "unorderedLinkedList.h"

int main(int argc, char* argv[]) {
	if (argc != 2) {
		std::cout << "Usage: cluster \"A=<file>;C=<file>\"" << std::endl;
		return -1;
	}

	ArgumentManager am(argc, argv);
	string infile = am.get("A");
	string outfile = am.get("C");

    // create graphFile object
	ifstream graphFile;
    // create clustersFile object
    ofstream clustersFile;

    // read in the graphFile.txt and convert to a c-string to
    // handle invisible characters
	graphFile.open(infile.c_str(), ios::in);
	clustersFile.open(outfile.c_str(), ios::out);
    
	int graphSize = 0;
	string line;
	int i = 0;
    // getting the size of the graph object to be made
	while (!graphFile.eof()) {
		getline(graphFile, line);
		if (line == "") {
			graphSize = i;
			break;
		}
		else {
			i++;
		}
	}
    
    // continue pass spaces
	while (!graphFile.eof()) {
		getline(graphFile, line);
		if (line == "") {
			break;
		}
	}
    
    // default cluster number is zero, however the the graph
    // itself is a cluster so default clusterCount is 1
	int cluster = 0, clustCount = 1;
	graphFile >> cluster;
    
    // empty files
	if (cluster < 1 || !graphFile || cluster > graphSize) {
		clustersFile << "";
	}
	else {
        // create graph object
		msTreeType<int> msGraph(graphSize);
		graphFile.clear();
        
        // move getline to the start of the file
		graphFile.seekg(0, ios::beg);
        // first create the spannig graph
		msGraph.createSpanningGraph(graphFile, clustersFile);
        // then create the minimum spanning tree
		msGraph.minimumSpanning(0);
        // update the tree
		msGraph.adjustMsTree();
		
		while (clustCount < cluster) {
			// delete the heaviest edges
			msGraph.trimTree();
			msGraph.adjustMsTree();
			clustCount++;
		}
        // put the clusters into the clustersFile
		msGraph.breadthFirstTraversal(clustersFile);
	}
      graphFile.close();
      clustersFile.close();
	return 0;
}

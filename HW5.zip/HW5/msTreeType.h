#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
#include <assert.h>
#include "unorderedLinkedList.h"
#include "linkedQueueType.h"
#include "linkedListIterator.h"
#include "orderedLinkedList.h"

template<class gType>
class msTreeType {
public:
	void createSpanningGraph(ifstream &infile, ofstream &outfile);
	void trimTree();
	void adjustMsTree();
	void minimumSpanning(int sVertex);
	void printTreeAndWeight();
	msTreeType(int size = 0);
	~msTreeType();
	//void printGraph() const;
	void clearGraph();
	void breadthFirstTraversal(ofstream &out);
protected:
	int source;
	double **weights;
	int *edges;
	double *edgeWeights;
	int cluster;
	unorderedLinkedList<int> *graph; //array to create adjacency lists
public:
	int gSize; //current number of vertices
	int maxSize; //maximum number of vertices
};

// create spanning graph
template<class gType>
void msTreeType<gType>::createSpanningGraph(ifstream &infile, ofstream &outfile) {
	// default values
    for (int i = 0; i < gSize; i++) {
		for (int j = 0; j < gSize; j++) {
			weights[i][j] = -999;
		}
	}
    // begin filling the graph object
	string node, num;
	int nodeCount = 0;
	while (!infile.eof()) {
		getline(infile, node);
		stringstream ss(node);
		if (node == "") {
			break;
		}
		while (ss >> num) {
			int nodeValue = stoi(num, nullptr, 10);
			graph[nodeCount].insertLast(nodeValue);
		}
		nodeCount++;
	} nodeCount = 0;

	int vertex = 0, adjacentVertex = 0;

    // filling in the weight matrix
	while (!infile.eof()) {
		getline(infile, node);
		stringstream ss(node);
		if (node == "") {
			break;
		}
		while (ss >> num) {
			int adjVert = stoi(num, nullptr, 10);
			weights[vertex][adjacentVertex] = adjVert;
			adjacentVertex++;
		}
		vertex++;
        // if the node value is greater the possilbe number of nodes then output a blank file
		if (adjacentVertex != gSize) {
			outfile << "";
			exit(0);
		}
		adjacentVertex = 0;
	}
    // if the node value is greater the possilbe number of nodes then output a blank file
	if (vertex != gSize) {
		outfile << "";
		exit(0);
	}

}

// adjusting the graph
template<class gType>
void msTreeType<gType>::adjustMsTree() {
	// holding the graph size
    int gSizeVal = gSize;
	clearGraph();
	gSize = gSizeVal;
	gSizeVal = 0;
    
    // repopulationg the graph object to show the pair values
	for (int edge = 0; edge < gSize; edge++) {
		if (edges[edge] == edge || edgeWeights[edge] == -999) {
			continue;
		}
		else {
			graph[edges[edge]].insertLast(edge);
			graph[edge].insertLast(edges[edge]);
		}
	}

}

// trimming the tree
template<class qType>
void msTreeType<qType>::trimTree() {
	int edgeVal = 0;
	double weightVal = 0;
    // if the weight value is is outside of the bounds then trim it
	for (int edge = 0; edge < gSize; edge++) {
		if (weightVal < edgeWeights[edge]) {
			weightVal = edgeWeights[edge];
			edgeVal = edge;
		}
	}

	edgeWeights[edgeVal] = -999;
}

// minimum spanning tree
template<class gType>
void msTreeType<gType>::minimumSpanning(int sVertex) {
	int startVertex, endVertex;
	double minWeight;
	source = sVertex;
	bool *mstv;
	mstv = new bool[gSize];
	// set the values to false
    for (int j = 0; j < gSize; j++)	{
		mstv[j] = false;
		edges[j] = source;
		edgeWeights[j] = weights[source][j];
	}
    // first node has been visited
	mstv[source] = true;
	edgeWeights[source] = 0;
    // begin creating the mstree
	for (int i = 0; i < gSize - 1; i++) {
		minWeight = DBL_MAX;
		for (int j = 0; j < gSize; j++)
			if (mstv[j])
				for (int k = 0; k < gSize; k++)
					if (!mstv[k] && weights[j][k] < minWeight && weights[j][k] != -999)
					{
						endVertex = k;
						startVertex = j;
						minWeight = weights[j][k];
					}
		mstv[endVertex] = true;
		edges[endVertex] = startVertex;
		edgeWeights[endVertex] = minWeight;
	} //end for
}

// function to examine the data structure on the console screen
template<class gType>
void msTreeType<gType>::printTreeAndWeight() {
	double treeWeight = 0;
    
	for (int j = 0; j < gSize; j++)
	{
		if (edges[j] != j) {
			treeWeight = treeWeight + edgeWeights[j];
			std::cout << "(" << edges[j] << ", " << j << ") "
				<< edgeWeights[j] << std::endl;
		}
	}
	std::cout << std::endl;
	std::cout << "Minimum spanning Tree Weight: "
		<< treeWeight << std::endl;
}

// Create ms. Tree Type
template<class gType>
msTreeType<gType>::msTreeType(int size) {
	if (gSize != 0) //if the graph is not empty, make it empty
		clearGraph();
	maxSize = size * 10;
	gSize = size;
	graph = new unorderedLinkedList<int>[size];
	weights = new double*[size];
	for (int i = 0; i < size; i++)
		weights[i] = new double[size];
	edges = new int[size];
	edgeWeights = new double[size];
}

// default destructor
template<class gType>
msTreeType<gType>::~msTreeType() {
	for (int i = 0; i < gSize; i++)
		delete[] weights[i];
	delete[] weights;
	delete[] edges;
	delete[] edgeWeights;
}

// reset graph
template <class gType>
void msTreeType<gType>::clearGraph() {
	for (int index = 0; index < gSize; index++)
		graph[index].destroyList();
	gSize = 0;
} //end clearGraph

// breadth first traversal function
template <class gType>
void msTreeType<gType>::breadthFirstTraversal(ofstream &out) {
	// que to keep track of the visited nodes
    linkedQueueType<int> queue;
    // list to keep track of the clusters
	orderedLinkedList<int> clusters;
	bool *visited;
	visited = new bool[gSize];
	for (int ind = 0; ind < gSize; ind++)
		visited[ind] = false;

	linkedListIterator<int> graphIt;
	for (int index = 0; index < gSize; index++)
		
		if (!visited[index]) {
			queue.addQueue(index);
			visited[index] = true;
    
			clusters.destroyList();
			clusters.insert(index);
			while (!queue.isEmptyQueue()) {
				int u = queue.front();
				queue.deleteQueue();
				for (graphIt = graph[u].begin();
					graphIt != graph[u].end(); ++graphIt) {
					int w = *graphIt;
					if (!visited[w]) {
						queue.addQueue(w);
						visited[w] = true;
						clusters.insert(w);
					}
				}
			} //end while
		
			
			clusters.print(out);
			out << std::endl;
			cerr << std::endl;
		}
	delete[] visited;
} //end breadthFirstTraversal
